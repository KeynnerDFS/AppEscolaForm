﻿using AppProjetoEscola.RegraDeNegocio;

List<SalaDeAula> salasDeAula = new List<SalaDeAula>();
int opcao = 1;
int contador = 1;

void CadastrarTurma()
{
    int opc = 1;
    while (opc != 0)
    {
        Console.Clear();
        Console.WriteLine("########### CADASTRAR TURMA ##########");
        Console.WriteLine();
        Console.Write("Série...............................:");
        var serie = Convert.ToInt32(Console.ReadLine());
        Console.Write("Nome da Turma.......................:");
        var nomeTurma = Console.ReadLine();
        SalaDeAula turma = new SalaDeAula(contador, serie, nomeTurma);
        //depois da sala criada, colocar a sala na lista
        salasDeAula.Add(turma);
        contador++;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Turma criada com sucesso!!!");
        Console.WriteLine();
        Console.ForegroundColor= ConsoleColor.White;
        Console.Write("Deseja continuar criando Turmas? (S/N).......:");
        var resp = Console.ReadLine().ToUpper();
        if (resp == "N") opc = 0;
    }//fim while
}//fim cadastrar turma

SalaDeAula SelecionarTurma()
{
    Console.Clear();
    Console.WriteLine("########## Selecionar Turma ##########");
    Console.WriteLine();
    Console.Write("Nome da Turma........................:");
    var nomeTurma = Console.ReadLine().ToUpper();
    var turmaSelecionada = salasDeAula.Where(sala => sala.NomeTurma.ToUpper() == nomeTurma).FirstOrDefault();
    if (turmaSelecionada == null)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Turma não encontrada!!!"); 
        Console.ReadKey();
    }
    Console.ForegroundColor = ConsoleColor.White;
    return turmaSelecionada;
}//fim selecionar turma

while (opcao != 0)
{
    Console.Clear();
    Console.WriteLine("########## ESCOLA XYZ ##########");
    Console.WriteLine();
    Console.WriteLine("1 - Cadastrar Turma");
    Console.WriteLine("2 - Cadastrar aluno");
    Console.WriteLine("3 - Consultar aluno");
    Console.WriteLine("4 - Filtrar alunos");
    Console.WriteLine("5 - Listar alunos aprovados");
    Console.WriteLine("6 - Listar alunos reprovados");
    Console.WriteLine("7 - Listar todos os alunos da turma");
    Console.WriteLine("8 - Estatistica da turma");
    Console.WriteLine("9 - Listar todos alunos da Escola");// desafio
    Console.WriteLine("0 - Sair do Sistema");
    Console.Write("Opção N°.......................:");
    opcao = Convert.ToInt32(Console.ReadLine());
    switch (opcao)
    {
        case 1:
            {
                CadastrarTurma();
                break;
            }

        case 2:
            {
                salasDeAula.Where(sala => sala == SelecionarTurma()).FirstOrDefault().CadastrarAlunos();
                break;
            }
        case 3:
            {
                salasDeAula.Where(sala => sala == SelecionarTurma()).FirstOrDefault().ConsultarAluno();
                break;
            }
        case 4:
            {
                salasDeAula.Where(sala => sala == SelecionarTurma()).FirstOrDefault().FiltarAlunos();
                break;
            }
    }
}