﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppProjetoEscola.RegraDeNegocio
{
    public class SalaDeAula
    {
        //atributos
        public int Id { get; set; }
        public int Serie { get; set; }
        public string NomeTurma { get; set; }

        public List<Aluno> AlunosMatriculados { get; set; }

        //método construtor
        public SalaDeAula(int id, int serie, string nomeTurma)
        {
            this.Id = id;
            this.Serie = serie;
            this.NomeTurma = nomeTurma;
            AlunosMatriculados = new List<Aluno>();
        }

        public void CadastrarAlunos()
        {
            int opcao = 1;
            while (opcao != 0)
            {
                Console.Clear();
                Console.WriteLine("########## Cadastrar Alunos ##########");
                Console.WriteLine();
                Console.WriteLine("Série:" + Serie + " / Turma:" + NomeTurma);
                Console.WriteLine();
                Aluno aluno = new Aluno();
                aluno.Id = AlunosMatriculados.Count+1;
                aluno.NumeroMatricula = AlunosMatriculados.Count+1000;
                Console.Write("Nome...............................:");
                aluno.Nome = Console.ReadLine();
                Console.Write("Nota1 ...............................:");
                aluno.Nota1 = Convert.ToDouble(Console.ReadLine());
                Console.Write("Nota2 ...............................:");
                aluno.Nota2 = Convert.ToDouble(Console.ReadLine());
                //colocar o aluno na lista (matricular o aluno)
                AlunosMatriculados.Add(aluno);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Aluno cadastrado com sucesso!!!");
                Console.WriteLine();
                Console.ForegroundColor= ConsoleColor.White;
                Console.Write("Deseja continuar cadastrando? (S/N)...:");
                var resp = Console.ReadLine().ToUpper();
                if (resp == "N") opcao = 0;
            }//Fim while
        }//fim do método cadastrar alunos 

        public void ConsultarAluno()
        {
            int opc = 1;
            while (opc != 0)
            {
                Console.Clear();
                Console.WriteLine("########## Consultar Alunos ##########");
                Console.WriteLine();
                Console.WriteLine("Série:" + Serie + " / Turma:" + NomeTurma);

                Console.Write("Nome............................:");
                var nome = Console.ReadLine().ToUpper();
                var aluno = AlunosMatriculados.Where(a => a.Nome.ToUpper() == nome).FirstOrDefault();//pegar o primeiro da lista
                if(aluno != null)
                {
                    Console.WriteLine("N° Matricula.............:"+aluno.NumeroMatricula);
                    Console.WriteLine("Nome.....................:"+aluno.Nome);
                    Console.WriteLine("Nota1....................:"+aluno.Nota1);
                    Console.WriteLine("Nota2....................:" + aluno.Nota2);
                    Console.WriteLine("Média....................:"+aluno.CalcularMedia());
                    Console.WriteLine("Situação....................:" + aluno.VerificarSituacao());
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Aluno não encontrado!!!");
                }
                Console.WriteLine();
                Console.ForegroundColor= ConsoleColor.White;
                Console.Write("Deseja continuar consultando? (S/N)....:");
                var resp = Console.ReadLine().ToUpper();
                if (resp == "N") opc = 0;
            }//fim While
        }//fim do método consultar aluno

        public void FiltarAlunos()
        {
            Console.Clear();
            Console.WriteLine("%%%%%%%%%%%%%%% Filtrar aluno por nome  %%%%%%%%%%%%%%%");
            Console.WriteLine();
            Console.WriteLine("Série:" + Serie + " / Turma:" + NomeTurma);
            Console.WriteLine();

            Console.Write("Pesquisar nome.......................:");
            var nome = Console.ReadLine();
            Console.WriteLine();
            //var pessoasSelecao = ListaPessoa.Where(x=>x.Nome.Contains(nome)).ToArray();
            var alunosSelecao = AlunosMatriculados.Where(x => x.Nome.ToUpper().Contains(nome.ToUpper())).ToList();

            foreach (var aluno in AlunosMatriculados )
            {
                Console.WriteLine("Nome.....:" + aluno.Nome);
                Console.WriteLine("Nota1......:" + aluno.Nota1);
                Console.WriteLine("Nota2......:" + aluno.Nota2);
                Console.WriteLine();
            }
            if (alunosSelecao.Count() < 1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[Nome inexistente]");
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.ReadKey();
        }// fim do método filtrar aluno

        public void ListarTodosAlunos()
        {
            Console.WriteLine("########## Listar Todos os Alunos ##########");
        }// fim do método listar todos alunos

        public void ListarAlunosAprovados()
        {
            Console.WriteLine("########## Listar Alunos Reprovados ##########");
        }// fim do método listar alunos aprovados

        public void ListarAlunosReprovados()
        {
            Console.WriteLine("########## Listar Alunos Reprovados ##########");
        }// fim do método listar alunos reprovados

        public void EstatisticaDaTurma()
        {
            Console.WriteLine("########## Estatisticas da Turma ##########");
        }// fim do método estatistica da turma

    }// fim classe SalaDeAula

}
