﻿using AppEscolaForm.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppEscolaForm.Contexto
{
    public static class Context
    {
        public static List<SalaDeAula> ListaSalas = new List<SalaDeAula>();
        public static List<Aluno> ListaAlunos = new List<Aluno>();
    }
}
