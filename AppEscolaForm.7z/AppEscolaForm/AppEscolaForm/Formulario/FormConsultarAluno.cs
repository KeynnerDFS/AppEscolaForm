﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppEscolaForm.Contexto;
using AppEscolaForm.Formulario;
using AppEscolaForm.Models;

namespace AppEscolaForm.Formulario
{
    public partial class FormConsultarAluno : Form
    {
        List<SalaDeAula> listaSalas = new List<SalaDeAula>();
        List<Aluno> listaAlunos = new List<Aluno>();
        int cont = 1;
        public FormConsultarAluno()
        {
            InitializeComponent();
            listaSalas = Context.ListaSalas.ToList();
            listaAlunos = Context.ListaAlunos.ToList();
            cbAluno.DataSource = listaAlunos.ToList();
            cbAluno.DisplayMember = "Nome";
            cbAluno.SelectedIndex = -1;
        }

        private void cbAluno_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbAluno.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var aluno = listaAlunos[linhaSelec];
                txtNome.Text = aluno.Nome;
                txtNumMatricula.Text = aluno.NumMatricula.ToString();
                txtNota1.Text = aluno.Nota1.ToString();
                txtNota2.Text = aluno.Nota2.ToString();
                var salaSelec = listaSalas.Where(m => m.Id == aluno.IdSalaDeAula).ToList();
                dtTabela.DataSource = salaSelec.ToList();
            }
            cont++;
        }
    }
}
