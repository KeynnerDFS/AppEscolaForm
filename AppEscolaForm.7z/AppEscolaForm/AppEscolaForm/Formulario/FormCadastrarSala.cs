﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppEscolaForm.Contexto;
using AppEscolaForm.Formulario;
using AppEscolaForm.Models;

namespace AppEscolaForm.Formulario
{
    public partial class FormCadastrarSala : Form
    {
        public static int Id = 1;
        public FormCadastrarSala()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtSerie.Clear(); txtAno.Clear(); txtTurma.Clear();
            txtSerie.Select(); //colocar o curso no campo
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            SalaDeAula sala = new SalaDeAula();
            sala.Serie = Convert.ToInt32(txtSerie.Text);
            sala.Turma = txtTurma.Text;
            sala.Ano = Convert.ToInt32(txtAno.Text);
            sala.Id = Id;
            Id++;
            Context.ListaSalas.Add(sala);
            MessageBox.Show("SALVO COM SUCESSO!", "2A/INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtSerie.Clear(); txtAno.Clear(); txtTurma.Clear();
            txtSerie.Select(); //colocar o curso no campo
        }
    }
}
