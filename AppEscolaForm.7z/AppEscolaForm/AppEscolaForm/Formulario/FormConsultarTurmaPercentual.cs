﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppEscolaForm.Contexto;
using AppEscolaForm.Formulario;
using AppEscolaForm.Models;
using static System.Windows.Forms.LinkLabel;

namespace AppEscolaForm.Formulario
{
    public partial class FormConsultarTurmaPercentual : Form
    {
        List<SalaDeAula> listaSalas = new List<SalaDeAula>();
        List<Aluno> listaAlunos = new List<Aluno>();
        int cont = 1;
        public FormConsultarTurmaPercentual()
        {
            InitializeComponent();
            listaSalas = Context.ListaSalas.ToList();
            listaAlunos = Context.ListaAlunos.ToList();
            cbTurma.DataSource = listaSalas.ToList();
            cbTurma.DisplayMember = "Turma";
            cbTurma.SelectedIndex = -1;
        }

        private void cbTurma_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbTurma.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var sala = listaSalas[linhaSelec];
                txtSerie.Text = sala.Serie.ToString();
                txtTurma.Text = sala.Turma.ToString();
                txtAno.Text = sala.Ano.ToString();
                var alunoSelec = listaAlunos.Where(m => m.IdSalaDeAula == sala.Id).ToList();
                txtTotalAluno.Text = alunoSelec.Count.ToString();

                var alunosAprovados = alunoSelec.Where(n => n.CalcularMedia() > 59).ToList();
                txtAlunosAprovados.Text = alunosAprovados.Count.ToString() + " (" + ((double)alunosAprovados.Count/alunoSelec.Count * 100).ToString("F2")+"%)";

                var alunosReprovados = alunoSelec.Where(n => n.CalcularMedia() < 60).ToList();
                txtAlunosReprovados.Text = alunosAprovados.Count.ToString() + " (" + ((double)alunosReprovados.Count / alunoSelec.Count * 100).ToString("F2") + "%)";


            }
            cont++;
        }

       
    }
}
